import java.util.Arrays;


public class Matrix {
	// we define the variables of the class
	int lines,cols;
	double[][] data;
	
	// we define one constructor to initialize our variables with values we need
	public Matrix(double[][] data, int lines, int cols){
		this.data=data;
		this.lines=lines;
		this.cols = cols;
	}
	// we define some getters to get number of lines and cols
	public int getNumberLines(){
		return this.lines;
	}
	
	public int getNumberCols(){
		return this.cols;
	}
	
	//we need to define a method to get by indexes the value of a given cell in the table
	public double getByIndexes(int i, int j){
		// better to check here the dimensions of the table
		double val = this.data[i][j];
		return val;
	}
	public Matrix add(Matrix m){
		// before we apply any calculation, we need to check that dimensions are equal
		if (this.lines == m.getNumberLines() && this.cols == m.getNumberCols()){
			double[][] sum_mat = new double[m.getNumberLines()][m.getNumberCols()];
			for(int i =0;i<this.lines;i++){
				for(int j =0;j<this.cols;j++){
					sum_mat[i][j] = this.getByIndexes(i,j)+ m.getByIndexes(i,j);
				}
			}
			return new Matrix(sum_mat, m.getNumberLines(), m.getNumberLines());
		}else{
		System.out.println("operation impossible, dimensions are not equal !");
		return null;
		}
	}
	
	public Matrix sub(Matrix m){
		// similarly ...
		return null;
	}
	
	public Matrix div(Matrix m){
		// similarly ...
		return null;
	}
	
	public Matrix mul(Matrix m){
		// similarly ...
		return null;
	}
	
	public double det(){
		// calculate 
		return 0.0;
	}
	
	public Matrix T(){
		// calculate the the transpose 
		return null;
	}
	
	public Matrix I(){
		// calculate the inverse matrix
		return null;
	}
	
	public String toString(){
		String serialized = "";
		for(double[] line: this.data){
			serialized += Arrays.toString(line)+"\n"; 
		}
		return serialized;
	}

}
