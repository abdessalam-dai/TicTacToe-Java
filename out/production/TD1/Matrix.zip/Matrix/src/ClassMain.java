
public class ClassMain {

	public static void main(String[] args){
		// we initialize directly two matrices: look chapter 2
		double[][] data1={{5,4,3,4},{4,-5,5,9},{1,4,8,8}};
		double[][] data2={{9,24,8,4},{10,5,10,9},{2,4,15,8}};
		//we initialize two variables for the number of lines and cols for matrix 1
		int lines1=0,cols1=0;
		lines1 = data1.length;
		if(lines1 >0){
			cols1 = data1[0].length;
		}
		
		
		//we initialize two variables for the number of lines and cols for matrix 2
		int lines2=0,cols2=0;
		lines2 = data2.length;
		if(lines2 >0){
			cols2 = data2[0].length;
		}
			
		//we create two matrixes 	
		Matrix m1 = new Matrix(data1,lines1,cols1);
		Matrix m2 = new Matrix(data2,lines2,cols2);
		
		// we calculate the sum and display all
		Matrix m3 = m1.add(m2);
		System.out.println("Sum of matrix 1:\n");
		System.out.println(m1);
		System.out.println("and matrix 2:");
		System.out.println(m2);
		System.out.println("is another matrix 3:");
		System.out.println(m3);
		
	}
}
