
public class Tile {
	String color;
	boolean done;
	double taken_time; 
	public Tile(String color){
		// you may like to randomize the color of the tile :D
		this.color=color;
		this.done=false;
		this.taken_time=0;
	}
	
	public void setDone(double t){
		this.done=true;
		this.taken_time=t;
	}
	
	public double getTakenTime(){
		return this.taken_time;
	}

}
