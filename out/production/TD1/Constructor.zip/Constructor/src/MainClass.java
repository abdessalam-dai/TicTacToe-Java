
public class MainClass {

	public static void main(String[] args) {
		// we imagine a scenario of a working day ...
		int max_packets_per_day = 10;
		int size_per_packet=12;
		Constructor cons = new Constructor("ESTIN", max_packets_per_day, size_per_packet);
		
		cons.putTile(4);
		cons.putTile(5);
		cons.putTile(4);
		cons.putTile(4);
		cons.putTile(5);
		cons.putTile(6);
		cons.putTile(6);
		cons.putTile(4);
		cons.putTile(6);
		cons.putTile(6);
		cons.putTile(6);
		cons.putTile(6);
		
		// after finishing the first packet, it looks like the constructor needs some rest ...
		cons.haveRest(10);
		
		// the constructor resume work
		cons.putTile(4);
		
		// ...
		// ...
		
		// display the total number of done tiles
		System.out.println(cons.getTotalNumberOfDoneTiles());
		

		// display the number of done tiles at t=9
		double t =9;
		System.out.println("I have put: "+ cons.getNumberOfDoneTilesAt(t)+"in "+t + " minutes.");
	}

}
