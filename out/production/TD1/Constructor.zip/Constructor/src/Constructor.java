
public class Constructor {
	String name;
	private int max_packet_per_day;
	private int current_packet;
	private int current_tile;
	private int size_packet;
	private double work_time;
	private double rest_time;
	private Tile[][] packets;
	
	
	public Constructor(String name, int max_packet_per_day,int size_packet){
		this.name=name;
		this.max_packet_per_day=max_packet_per_day;
		this.size_packet=size_packet;
		this.packets= new Tile[max_packet_per_day][];
		
		this.current_packet=0;
		this.current_tile=0;
		
		this.work_time=0;
		this.rest_time=0;	
	}
	
	public void haveRest(double t){
		this.rest_time+=t;
	}
	
	public void putTile(double t){
		// add code to update the packets table 
		//...
		//...
		//...
		this.work_time+=t;
	}
	
	public int getTotalNumberOfDoneTiles(){
		return 0;
	}
	
	public int getNumberOfDoneTilesAt(double t){
		// check the table to get the number
		// ...
		// ...
		
		return 0;
	}
	
	public double getWorkingTime(){
		// calculate it ...
		return 0.0;
	}
	
	public double getAverageTimePerTile(){
		// calculate it ...
		return 0.0;
	}
	

}
