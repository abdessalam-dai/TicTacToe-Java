
public class MainClass {
	public static void main(String[] args){
		double[] notes = {11.0,15.0,5,19.0,7.2};
		Etudiant et1 = new Etudiant("Estin","Amizour",notes);
		System.out.println("L'etudiant:");
		System.out.println("Nom :"+et1.getNom());
		System.out.println("Prenom :"+et1.getPrenom());
		System.out.println("Moyenne: "+et1.CalculateAVG());
	}
}
