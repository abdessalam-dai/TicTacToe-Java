
public class Etudiant {
	String nom,prenom;
	double[] notes;
	public Etudiant(String nom,String prenom,double[] notes){
		this.nom=nom;
		this.prenom=prenom;
		this.notes=notes;
	}
	
	public String getNom(){
		return this.nom;
	}
	
	public String getPrenom(){
		return this.prenom;
	}
	
	public void setNom(String nom){
		this.nom=nom;
	}
	
	public void setPrenom(String prenom){
		this.prenom=prenom;
	}
	
	public double CalculateAVG(){
		double sum=0;
		for(double val:this.notes){
			sum+=val;
		}
		if(this.notes.length>0){
			return sum/this.notes.length;
		}
		else{
		return 0.0;
		}
	}
	
}
